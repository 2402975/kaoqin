function varargout = facerecg(varargin)
% FACERECG MATLAB code for facerecg.fig
%      FACERECG, by itself, creates a new FACERECG or raises the existing
%      singleton*.
%
%      H = FACERECG returns the handle to a new FACERECG or the handle to
%      the existing singleton*.
%
%      FACERECG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FACERECG.M with the given input arguments.
%
%      FACERECG('Property','Value',...) creates a new FACERECG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before facerecg_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to facerecg_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help facerecg

% Last Modified by GUIDE v2.5 14-Jan-2021 14:09:07

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @facerecg_OpeningFcn, ...
    'gui_OutputFcn',  @facerecg_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before facerecg is made visible.
function facerecg_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to facerecg (see VARARGIN)

% Choose default command line output for facerecg
handles.output = hObject;
set(gcf,'name','��ϵ΢��:matlab1998 ');



% Update handles structure
guidata(hObject, handles);

% UIWAIT makes facerecg wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = facerecg_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



% --- Executes on button press in pushbuttonloadimg.
function pushbuttonloadimg_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonloadimg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%�ļ�ɸѡ�� ѡ��ͼƬ
[filename,pathname] = uigetfile({'*.jpg;*.bmp;*.tif;*.png;*.gif','All Image Files'},'��ѡ��һ��ͼƬ');
if filename == 0%���û��ѡ��ֱ�ӷ��ؼ���
    return;
end
strfullname = strcat(pathname,filename);%ȡ��ͼ���ļ�ȫ��

I = imread(strfullname);%��ȡͼƬ
axes(handles.axes1)
imshow(I);%��ʾͼƬ
title('����ͼ��')
save I
%���뵽handles�ڣ��Ա㱻��ĺ�������
handles.I = I;
handles.faceI = I;
% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in pushbuttonfacedetect.
function pushbuttonfacedetect_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonfacedetect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
msgbox('΢��:matlab1998')
% Update handles structure
guidata(hObject, handles);




% --- Executes on button press in pushbuttonreco.
function pushbuttonreco_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonreco (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%load num1 num2 num3 num4 num5 num6 num7 num8 num9 num10

msgbox('δ�������ˣ�����ϵ΢��:matlab1998')





% --- Executes on button press in pushbuttonsave.
function pushbuttonsave_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonsave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(isfield(handles,'faceI') && ~isempty(handles.faceI)) %�����������
    faceI = handles.faceI;
    [filename ,pathname]=uiputfile({'*.bmp','BMP-files(*.bmp)';'*.jpg','JPG-files(*.jpg)'},'����');%pathname��ȡ��������·����
    if filename == 0%���û��ѡ��ֱ�ӷ��ؼ���
        return;
    end
    strfullname = strcat(pathname,filename);%ȡ��ͼ���ļ�ȫ��
    imwrite(faceI,strfullname);
    
end


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
msgbox('�汾��ͬ�п��ܲ�����');
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
msgbox('��Ҫ����ϵ΢��:matlab1998')
ax1=(handles.axes1);cla(ax1,'reset')
ax2=(handles.axes2);cla(ax2,'reset')
set(handles.text9,'string',' ');
set(handles.text20,'string',' ');
set(handles.text21,'string',' ');
set(handles.text22,'string',' ');
set(handles.text23,'string',' ');
set(handles.text24,'string',' ');
set(handles.text25,'string',' ');
set(handles.text26,'string',' ');
set(handles.text27,'string',' ');
set(handles.text28,'string',' ');%
set(handles.reporttext,'string',' ');
set(handles.text4,'string',' ')
set(handles.text5,'string',' ')


% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)

str = sprintf('%d��',num1);
set(handles.text9,'string',str);

str = sprintf('%d��',num2);
set(handles.text20,'string',str);

str = sprintf('%d��',num3);
set(handles.text21,'string',str);

str = sprintf('%d��',num4);
set(handles.text22,'string',str);

str = sprintf('%d��',num5);
set(handles.text23,'string',str);

str = sprintf('%d��',num6);
set(handles.text24,'string',str);

str = sprintf('%d��',num7);
set(handles.text25,'string',str);

str = sprintf('%d��',num8);
set(handles.text26,'string',str);

str = sprintf('%d��',num9);
set(handles.text27,'string',str);

str = sprintf('%d��',num10);
set(handles.text28,'string',str);
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
